import React from "react";

const test = () => {
  return <h1>TEST Page</h1>;
};

export default test;
