import React from "react";

const Error = () => {
  return <h1>존재하지 않는 페이지 입니다!</h1>;
};

export default Error;
