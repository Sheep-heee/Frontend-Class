import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
// import App from "./App.tsx";
import App01 from "./App01.tsx";

createRoot(document.getElementById("root")!).render(<App01 />);
